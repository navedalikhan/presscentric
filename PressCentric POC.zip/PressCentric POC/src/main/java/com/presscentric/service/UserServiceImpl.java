package com.presscentric.service;

import java.io.Serializable;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.presscentric.dao.UserDao;
import com.presscentric.model.User;

/**
 * @author Ouctus Technology Pvt Ltd.
 *
 */
@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private UserDao userDao;
	
	@Override
	public User save(User entity) {
		return userDao.save(entity);
	}

	@Override
	public User getById(Serializable id) {
		return userDao.findOne((Long) id);
	}

	@Override
	public List<User> getAll() {
		return userDao.findAll();
	}

	@Override
	public void delete(Serializable id) {
		userDao.delete((Long) id);
	}
	

}
