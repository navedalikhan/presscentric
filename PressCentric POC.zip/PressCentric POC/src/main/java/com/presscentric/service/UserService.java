/**
 * 
 */
package com.presscentric.service;

import com.presscentric.model.User;

/**
 * @author Ouctus Technology Pvt Ltd.
 *
 */
public interface UserService extends CRUDService<User>  {
}
