/**
 * 
 */
package com.presscentric.controller;

import java.util.Arrays;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.presscentric.model.User;
import com.presscentric.service.UserService;

/**
 * @author Ouctus Technology Pvt Ltd.
 *
 */
@RestController
@RequestMapping(path="/presscentric/v1/users")
public class UserController {
	
	final static Logger logger = Logger.getLogger(UserController.class);
	
	@Autowired
	private UserService userService;
	
	@RequestMapping(method = RequestMethod.GET)
	public ResponseEntity<List<User>> allUsers() {
		List<User> users = userService.getAll();
		if (users.isEmpty()) {
			logger.debug("User does not exists");
			return new ResponseEntity<List<User>>(HttpStatus.NO_CONTENT);
		}
		logger.debug("Found " + users.size() + " User");
		logger.debug(Arrays.toString(users.toArray()));
		return new ResponseEntity<List<User>>(users, HttpStatus.OK);
	}
	
	@RequestMapping(method = RequestMethod.GET, path="/{id}")
    public ResponseEntity<User> userById(@PathVariable final Long id) {
		User existingUser = userService.getById(id);
		if(existingUser == null) {
			logger.debug("User with id " + id + " does not exists");
			return new ResponseEntity<User>(HttpStatus.NOT_FOUND);
		}
		logger.debug("Found User:: " + existingUser);
		return new ResponseEntity<User>(existingUser, HttpStatus.OK);
	}
	
	@RequestMapping(method = RequestMethod.POST)
	public ResponseEntity<User> createUser(@RequestBody final User user) {
		userService.save(user);
		logger.debug("Added:: " + user);
		return new ResponseEntity<User>(user, HttpStatus.CREATED);
	} 
	
	@RequestMapping(method = RequestMethod.PUT)
	public ResponseEntity<Void> updateUser(@RequestBody final User user) {
		User existingUser = userService.getById(user.getId());
		if(existingUser == null) {
			logger.debug("User with id " + user.getId() + " does not exists");
			return new ResponseEntity<Void>(HttpStatus.NOT_FOUND);
		}
		userService.save(user);
		return new ResponseEntity<Void>(HttpStatus.OK);
	} 
	
	@RequestMapping(method = RequestMethod.DELETE, path="/{id}")
	public ResponseEntity<Void> deleteUser(@PathVariable final Long id) {
		User existingUser = userService.getById(id);
		if(existingUser == null) {
			logger.debug("User with id " + id + " does not exists");
			return new ResponseEntity<Void>(HttpStatus.NOT_FOUND);
		}
		userService.delete(id);
		logger.debug("User with id " + id + " deleted");
		return new ResponseEntity<Void>(HttpStatus.NO_CONTENT);
	} 

}
