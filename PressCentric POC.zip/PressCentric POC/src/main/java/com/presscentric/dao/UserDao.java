/**
 * 
 */
package com.presscentric.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.presscentric.model.User;

/**
 * @author Ouctus Technology Pvt Ltd.
 *
 */
@Repository
public interface UserDao extends JpaRepository<User, Long> {
}
