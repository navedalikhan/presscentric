package com.presscentric;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * @author Ouctus Technology Pvt Ltd.
 *
 */
@SpringBootApplication
public class PressCentricPocApplication {

	public static void main(String[] args) {
		SpringApplication.run(PressCentricPocApplication.class, args);
	}
}
